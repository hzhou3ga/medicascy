This program uses the original 6 types of features coming with the Zhang dataset:

*_orgchfea.txt    chemical structure
*_orgpafea.txt    pathways
*_orgenzfea.txt   enzymes
*_orgtafea.txt    targets
*_orgtrefea.txt   treatments
*_orgtrafea.txt   transporters


To reproduce:
./scan_all_jkn_boostrf_orgall_null.job

To assess:
./scan_testorgallnull_2260_kn.job
