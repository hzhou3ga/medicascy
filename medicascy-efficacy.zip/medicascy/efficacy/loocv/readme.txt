Uses 2 types of predicted features
Parallel computing is required !




To reproduce:

First get Tc mapping:
./gettc.job

Then
./scan_all_jkn_boostrf_top1_ent_null_knowgene_excl.job 

To assess:
./scan_all_jkn_top1_ent_null_knowgene_boostrf_2_excl_kn.job drug_indication_comb_cls_drug.lst score_cutoff tc_cutoff
e.g
./scan_all_jkn_top1_ent_null_knowgene_boostrf_2_excl_kn.job drug_indication_comb_cls_drug.lst 0.5  0.7

