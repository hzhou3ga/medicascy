these are files needed for training
