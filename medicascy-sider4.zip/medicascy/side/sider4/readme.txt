This program uses predicted 2 types of features 
Parallel computing is required !

To reproduce :
./scan_all_jkn_boostrf_top1_ent_null_knowgene.job 

To assess : 
for all side effects
./scan_all_jkn_top1_ent_null_boostrf_2_excl_kn.job  drug_sider4.lst   score_cutoff  tc_cutoff

for killing side effects
./scan_all_jkn_boostrf_2_mycomb_top1_ent_null_knowgene_kill_excl_kn.job drug_sider4.lst   score_cutoff  tc_cutoff
